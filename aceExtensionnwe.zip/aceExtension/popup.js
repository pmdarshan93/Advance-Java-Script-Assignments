document.addEventListener('DOMContentLoaded', function () {

    document.getElementById('addToken').onclick = function () {
        document.getElementById('formOverlay').classList.remove('hidden');
    };

    document.getElementById('closeForm').onclick = function () {
        document.getElementById('formOverlay').classList.add('hidden');
    };

    document.getElementById('infoClose').onclick = function () {
        document.getElementById('infoOverlay').classList.add('hidden');
    };

    document.getElementById('formOverlay').onclick = function (e) {
        if (e.target === e.currentTarget) {
            e.currentTarget.classList.add('hidden');
        }
    };

    document.getElementById('infoOverlay').onclick = function (e) {
        if (e.target === e.currentTarget) {
            e.currentTarget.classList.add('hidden');
        }
    };

    document.getElementById('toggleSecret').onclick = function () {
        var inp = document.getElementById('clientSecret');
        inp.type = inp.type === 'password' ? 'text' : 'password';
    };

    function showmessage(msg, type) {
        var t = document.getElementById('message');
        t.textContent = msg;
        t.className = 'message' + (type ? ' ' + type : '');
        t.classList.remove('hidden');
        setTimeout(function () {
            t.classList.add('hidden');
        }, 2000);
    }

    function copyToken(button) {
        var tile = button.closest('.token-tile');
        if (!tile) return;

        var tokenEl = tile.querySelector('.tile-token');
        if (!tokenEl) return;

        var tokenValue = tokenEl.textContent.trim();

        navigator.clipboard.writeText(tokenValue).then(function () {
            showmessage('Token copied!', 'success');
        }).catch(function () {
            showmessage('Token copy failed!', 'error');
        });
    }

    function deleteToken(button) {
        var tile = button.closest('.token-tile');
        if (!tile) return;

        tile.remove();
        showmessage('Token deleted.', 'error');
    }

    function showInfo(tile) {
        var name = tile.querySelector('.tile-name');
        var token = tile.querySelector('.tile-token');
        var scope = tile.querySelector('.tile-scope');

        var infoScope = document.getElementById('infoScope');
        if (!infoScope) return;

        document.getElementById('infoName').textContent = name ? name.textContent : '';
        document.getElementById('infoToken').textContent = token ? token.textContent : '';
        document.getElementById('infoScope').textContent = scope ? scope.textContent : '';
        document.getElementById('infoCreated').textContent = new Date().toLocaleString();

        document.getElementById('infoOverlay').classList.remove('hidden');
    }

    document.getElementById('token_list').addEventListener('click', function (e) {

        var tile = e.target.closest('.token-tile');
        if (!tile) return;

        var copyBtn = e.target.closest('.tile-btn.copy');
        if (copyBtn) {
            copyToken(copyBtn);
            return;
        }

        var deleteBtn = e.target.closest('.tile-btn.delete');
        if (deleteBtn) {
            deleteToken(deleteBtn);
            return;
        }

        var infoBtn = e.target.closest('.tile-info');
        if (infoBtn) {
            showInfo(tile);
            return;
        }
    });

});
/*

token structure

 <li class="token-tile">
    <div class="tile-top">
        <span class="tile-dot valid"></span>
        <span class="tile-name">Cliq Webhook Dev</span>
        <button class="tile-info" title="Details">ℹ</button>
    </div>
    <div class="tile-token">1000.abc123def456xyz...</div>
    <div class="tile-scope">ZohoCliq.webhooks.CREATE</div>
    <div class="tile-actions">
        <button class="tile-btn copy" id="copy">📋 Copy</button>
        <button class="tile-btn regen">↻ Regen</button>
        <button class="tile-btn delete">✕ Del</button>
    </div>
</li>

<li class="token-tile">
    <div class="tile-top">
        <span class="tile-dot valid"></span>
        <span class="tile-name">Cliq Webhook Dev</span>
        <button class="tile-info" title="Details">ℹ</button>
    </div>
    <div class="tile-token">1000.abc123def456xyz...</div>
    <div class="tile-scope">ZohoCliq.webhooks.CREATE</div>
    <div class="tile-actions">
        <button class="tile-btn copy" id="copy">📋 Copy</button>
        <button class="tile-btn regen">↻ Regen</button>
        <button class="tile-btn delete">✕ Del</button>
    </div>
</li>

*/